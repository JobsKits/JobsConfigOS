# `【MacOS】🧾更新gitmodules.command`

![Jobs出品，必属精品](https://picsum.photos/1500/400)

[toc]

---

## 🔥 <span id="前言">前言</span>

依据所选磁盘目录建立父子 Git 关联，校验后更新当前父仓 .gitmodules 与 gitlink；实际写入前展示范围并确认。

## 一、入口与目录 <a href="#前言" style="font-size:17px; color:green;"><b>🔼</b></a> <a href="#🔚" style="font-size:17px; color:green;"><b>🔽</b></a>

脚本与本 README 位于同名包装目录。查看[实际脚本](<./【MacOS】🧾更新gitmodules.command>)及[上级工程说明](../README.md)后，按内置自述决定是否执行；运行位置从脚本实际路径解析，不依赖启动工作目录。迁移时保留工程的配套资源和相对层级。

## 二、只读验证 <a href="#前言" style="font-size:17px; color:green;"><b>🔼</b></a> <a href="#🔚" style="font-size:17px; color:green;"><b>🔽</b></a>

在本 README 所在目录只检查原生语法：

```shell
/bin/zsh -n './【MacOS】🧾更新gitmodules.command'
```

语法通过不代表真实下载、安装或配置写入已验收。交互沿用脚本自身确认与 Ctrl+C；日志、备份和退出状态以实际脚本自述为准。完整审查见总配置仓的 `项目相关报告/脚本统一审查.md`。

<a id="🔚" href="#前言" style="font-size:17px; color:green; font-weight:bold;">我是有底线的➤点我回到首页</a>
