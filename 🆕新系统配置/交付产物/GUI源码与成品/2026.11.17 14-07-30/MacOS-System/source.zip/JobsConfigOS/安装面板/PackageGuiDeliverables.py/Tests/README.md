# GUI交付打包测试

![Jobs出品，必属精品](https://picsum.photos/1500/400)

[toc]

---

## 🔥 <span id="前言">前言</span>

[测试源码](./PackageGuiDeliverablesTests.py/PackageGuiDeliverablesTests.py)验证打包器的归档、回执、路径、过滤及九套原子发布合同，使用开发机已有 [**Python**](https://www.python.org/) 标准库，不调用系统安装器。详细运行与边界见[测试说明](./PackageGuiDeliverablesTests.py/README.md)。

<a id="🔚" href="#前言">我是有底线的➤点我回到首页</a>
