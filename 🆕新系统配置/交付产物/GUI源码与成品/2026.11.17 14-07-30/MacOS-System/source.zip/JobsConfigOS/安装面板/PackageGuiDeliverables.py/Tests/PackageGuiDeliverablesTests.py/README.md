# PackageGuiDeliverablesTests.py

![Jobs出品，必属精品](https://picsum.photos/1500/400)

[toc]

---

## 🔥 <span id="前言">前言</span>

仅用 [**Python**](https://www.python.org/) 3.9+ 标准库和独立临时目录验证GUI交付归档，不构建/启动真实程序，不调用安装或卸载后端。

## 一、<span id="run">运行与验证边界</span> <a href="#前言">🔼</a> <a href="#🔚">🔽</a>

```sh
python3 -B './PackageGuiDeliverablesTests.py'
```

13组测试覆盖路径/链接/秘密文件拒绝、源码变更、产品和缓存过滤、确定性ZIP、摘要读回、Mac回执、Payload完整性及system/env当前源变化/缺失而包未刷新的拒绝、PE格式、九套固定范围、输出隔离和九套完整归档夹具。临时PE/App只用于格式与事务测试；Mac签名命令在测试中替身，不把夹具称为实际二进制构建或目标OS运行通过。测试结束清理本测试自有临时目录，不清理正式交付物。

<a id="🔚" href="#前言">我是有底线的➤点我回到首页</a>
