# 新系统组件后端测试

![Jobs出品，必属精品](https://picsum.photos/1500/400)

[toc]

---

## 🔥 <span id="前言">前言</span>

[生命周期测试](./lifecycle_tests.py/README.md)使用已有 Python 标准库，为每个场景创建独立临时 HOME 和假 Node/npm/brew。不会下载软件、触发系统安装器或卸载本机环境。

## 一、运行

    python3 ./lifecycle_tests.py/lifecycle_tests.py --yes

真实入口会复制到中文与空格路径，从工程外工作目录执行。测试结果输出本轮临时目录，失败现场保留供核对。生产入口不依赖 Python。

<a id="🔚" href="#前言">回到前言</a>
