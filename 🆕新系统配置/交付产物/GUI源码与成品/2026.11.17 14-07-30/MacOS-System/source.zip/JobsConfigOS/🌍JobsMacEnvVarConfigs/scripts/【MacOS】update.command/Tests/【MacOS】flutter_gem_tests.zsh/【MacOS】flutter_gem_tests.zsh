#!/bin/zsh
# 脚本自述：
# - 脚本名称：【MacOS】flutter_gem_tests.zsh
# - 核心用途：隔离验证全局 Flutter 发现、FVM 缓存保护、失败传播与 Gem 用户目录回退。
# - 影响范围：仅使用专属临时目录和假命令，不联网、不升级真实 SDK 或 Gem。
# - 运行提示：自动执行回归；按 Ctrl+C 可取消。

# >>> Jobs terminal style protection v1 >>>
# 临时保护当前终端配色，业务进程自行管理原有退出清理。
jobs_terminal_style_run() {
    # 无法可靠保存原色时，沿用脚本已有的纯文本约定。
    jobs_terminal_style_plain() {
        PLAIN_OUTPUT=1
        NO_COLOR=1
        FORCE_COLOR=0
        CLICOLOR=0
        ANSI_COLORS_DISABLED=1
        npm_config_color=false
        export PLAIN_OUTPUT NO_COLOR FORCE_COLOR CLICOLOR ANSI_COLORS_DISABLED npm_config_color
        if "$@"; then
            jobs_style_exit_status=0
        else
            jobs_style_exit_status=$?
        fi
        exit "$jobs_style_exit_status"
    }
    if [ ! -t 0 ] || [ ! -t 1 ] || [ -z "${TERM:-}" ] ||
       [ "${TERM:-}" = dumb ] || [ "${NO_COLOR+x}" = x ] ||
       [ "${PLAIN_OUTPUT:-0}" = 1 ] || [ "${IS_SOURCETREE_RUNTIME:-0}" = 1 ] ||
       env | LC_ALL=C grep -qiE '^(SOURCETREE|SOURCE_TREE)'; then
        if "$@"; then
            jobs_style_exit_status=0
        else
            jobs_style_exit_status=$?
        fi
        exit "$jobs_style_exit_status"
    fi
    if [ -n "${TMUX:-}${STY:-}" ]; then
        jobs_terminal_style_plain "$@"
    fi
    jobs_style_tty=$(tty 2>/dev/null) || jobs_terminal_style_plain "$@"
    if ! ps -o pgid= -o tpgid= -p "$$" 2>/dev/null |
         LC_ALL=C awk 'NF == 2 && $1 == $2 && $1 > 0 { foreground = 1 } END { exit !foreground }'; then
        jobs_terminal_style_plain "$@"
    fi
    case ${JOBS_TERMINAL_STYLE_OWNER:-} in
        ''|*[!0-9]*) ;;
        *)
            if [ "${JOBS_TERMINAL_STYLE_TTY:-}" = "$jobs_style_tty" ] &&
               kill -0 "$JOBS_TERMINAL_STYLE_OWNER" 2>/dev/null; then
                if "$@"; then
                    jobs_style_exit_status=0
                else
                    jobs_style_exit_status=$?
                fi
                exit "$jobs_style_exit_status"
            fi
            ;;
    esac
    jobs_style_stty=$(stty -g 2>/dev/null < /dev/tty) || jobs_terminal_style_plain "$@"
    jobs_style_saved=''
    jobs_style_saved_rows=''
    jobs_style_original_rows=''
    jobs_style_applied_rows=''
    jobs_style_changed=0
    jobs_style_applied_complete=0
    jobs_style_query_active=0
    jobs_style_recovery=''
    jobs_style_exit_status=0
    jobs_style_esc=$(printf '\033')
    jobs_style_bel=$(printf '\007')
    # 完整颜色帧有界重发；设置核验与退出恢复容忍帧外回车和明确方向键。
    jobs_terminal_style_query() {
        jobs_style_query_key=$1
        jobs_style_reply=''
        jobs_style_query_buffer=''
        jobs_style_query_target_reply=''
        jobs_style_query_target_normalized=''
        jobs_style_query_target_rgb=''
        jobs_style_query_st="${jobs_style_esc}\\"
        jobs_style_query_stale_count=0
        jobs_style_query_phase=${2:-strict}
        jobs_style_query_cr=$(printf '\r')
        jobs_style_query_lf=$(printf '\n.')
        jobs_style_query_lf=${jobs_style_query_lf%.}
        jobs_style_query_failure='未收到目标颜色的完整答复（最多 3 次查询，每次约 2 秒）'
        for jobs_style_query_round in 1 2 3; do
            printf '\033]%s;?\007' "$jobs_style_query_key" > /dev/tty || {
                jobs_style_query_failure='无法向原终端发送配色查询'
                return 1
            }
            for jobs_style_attempt in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
                # 哨兵保留末尾换行，不能把只有回车的键盘输入误当成无答复。
                jobs_style_piece=$(dd bs=256 count=1 2>/dev/null < /dev/tty; printf '.')
                jobs_style_piece=${jobs_style_piece%.}
                jobs_style_query_buffer=$jobs_style_query_buffer$jobs_style_piece
                while [ -n "$jobs_style_query_buffer" ]; do
                    # 设置核验与退出恢复阶段允许帧外的明确控制键，普通文字仍然失败。
                    if [ "$jobs_style_query_phase" = cleanup ] || [ "$jobs_style_query_phase" = applied ]; then
                        jobs_style_query_control_sequence=''
                        jobs_style_query_control_partial=0
                        case $jobs_style_query_buffer in
                            "$jobs_style_query_cr"*) jobs_style_query_control_sequence=$jobs_style_query_cr ;;
                            "$jobs_style_query_lf"*) jobs_style_query_control_sequence=$jobs_style_query_lf ;;
                        esac
                        if [ -z "$jobs_style_query_control_sequence" ]; then
                            for jobs_style_query_direction in A B C D; do
                                for jobs_style_query_control_candidate in \
                                    "${jobs_style_esc}[${jobs_style_query_direction}" \
                                    "${jobs_style_esc}O${jobs_style_query_direction}" \
                                    "${jobs_style_esc}[1;2${jobs_style_query_direction}" \
                                    "${jobs_style_esc}[1;3${jobs_style_query_direction}" \
                                    "${jobs_style_esc}[1;4${jobs_style_query_direction}" \
                                    "${jobs_style_esc}[1;5${jobs_style_query_direction}" \
                                    "${jobs_style_esc}[1;6${jobs_style_query_direction}" \
                                    "${jobs_style_esc}[1;7${jobs_style_query_direction}" \
                                    "${jobs_style_esc}[1;8${jobs_style_query_direction}"; do
                                    case $jobs_style_query_buffer in
                                        "$jobs_style_query_control_candidate"*)
                                            jobs_style_query_control_sequence=$jobs_style_query_control_candidate
                                            break 2
                                            ;;
                                    esac
                                    case $jobs_style_query_control_candidate in
                                        "$jobs_style_query_buffer"*) jobs_style_query_control_partial=1 ;;
                                    esac
                                done
                            done
                        fi
                        if [ -n "$jobs_style_query_control_sequence" ]; then
                            jobs_style_phase_control_keys=$(( ${jobs_style_phase_control_keys:-0} + 1 ))
                            if [ "$jobs_style_phase_control_keys" -gt 64 ]; then
                                jobs_style_query_failure='本阶段已识别控制键超过 64 个，已停止自动恢复'
                                return 1
                            fi
                            jobs_style_query_buffer=${jobs_style_query_buffer#"$jobs_style_query_control_sequence"}
                            continue
                        fi
                        if [ "$jobs_style_query_control_partial" = 1 ]; then
                            break
                        fi
                    fi
                    case $jobs_style_query_buffer in
                        "$jobs_style_esc"|"$jobs_style_esc]") break ;;
                        "$jobs_style_esc]"*) ;;
                        *) jobs_style_query_failure='收到非配色查询输入，已停止读取'; return 1 ;;
                    esac
                    jobs_style_query_head=''
                    jobs_style_query_terminator=''
                    case $jobs_style_query_buffer in
                        *"$jobs_style_bel"*)
                            jobs_style_query_head=${jobs_style_query_buffer%%"$jobs_style_bel"*}
                            jobs_style_query_terminator=$jobs_style_bel
                            ;;
                    esac
                    case $jobs_style_query_buffer in
                        *"$jobs_style_query_st"*)
                            jobs_style_query_st_head=${jobs_style_query_buffer%%"$jobs_style_query_st"*}
                            if [ -z "$jobs_style_query_terminator" ] ||
                               [ "${#jobs_style_query_st_head}" -lt "${#jobs_style_query_head}" ]; then
                                jobs_style_query_head=$jobs_style_query_st_head
                                jobs_style_query_terminator=$jobs_style_query_st
                            fi
                            ;;
                    esac
                    [ -n "$jobs_style_query_terminator" ] || break
                    jobs_style_query_frame=$jobs_style_query_head$jobs_style_query_terminator
                    jobs_style_query_buffer=${jobs_style_query_buffer#"$jobs_style_query_frame"}
                    jobs_style_query_body=${jobs_style_query_head#"$jobs_style_esc]"}
                    case $jobs_style_query_body in
                        *';rgb:'*) ;;
                        *) jobs_style_query_failure='配色答复格式或 RGB 数据无效'; return 1 ;;
                    esac
                    jobs_style_query_frame_key=${jobs_style_query_body%%';rgb:'*}
                    case $jobs_style_query_frame_key in
                        10|11|12|'4;'[0-9]|'4;1'[0-5]) ;;
                        *) jobs_style_query_failure='收到不属于本次颜色协议的答复'; return 1 ;;
                    esac
                    jobs_style_query_frame_rgb=${jobs_style_query_body#"$jobs_style_query_frame_key;rgb:"}
                    jobs_style_query_frame_normalized=$(printf '%s\n' "$jobs_style_query_frame_rgb" | LC_ALL=C awk -F/ '
                        BEGIN { valid = 1 }
                        NR != 1 || NF != 3 { valid = 0; exit }
                        {
                            for (i = 1; i <= 3; i++) {
                                h = tolower($i)
                                if (length(h) < 1 || length(h) > 4 || h ~ /[^0-9a-f]/) {
                                    valid = 0
                                    exit
                                }
                                n = 0
                                for (j = 1; j <= length(h); j++) n = n * 16 + index("0123456789abcdef", substr(h, j, 1)) - 1
                                value[i] = int(n * 65535 / (16 ^ length(h) - 1) + 0.5)
                            }
                        }
                        END {
                            if (!valid || NR != 1) exit 1
                            printf "%d/%d/%d", value[1], value[2], value[3]
                        }
                    ')
                    if [ -z "$jobs_style_query_frame_normalized" ]; then
                        jobs_style_query_failure='配色答复格式或 RGB 数据无效'
                        return 1
                    fi
                    if [ "$jobs_style_query_frame_key" = "$jobs_style_query_key" ]; then
                        if [ -n "$jobs_style_query_target_reply" ] &&
                           [ "$jobs_style_query_target_normalized" != "$jobs_style_query_frame_normalized" ]; then
                            jobs_style_query_failure='同一颜色的重复答复不一致，已停止自动恢复'
                            return 1
                        fi
                        jobs_style_query_target_reply=$jobs_style_query_frame
                        jobs_style_query_target_normalized=$jobs_style_query_frame_normalized
                        jobs_style_query_target_rgb=$jobs_style_query_frame_rgb
                    else
                        jobs_style_query_stale_count=$((jobs_style_query_stale_count + 1))
                        if [ "$jobs_style_query_stale_count" -gt 128 ]; then
                            jobs_style_query_failure='收到过多旧颜色答复，已停止读取'
                            return 1
                        fi
                    fi
                done
                if [ -n "$jobs_style_query_target_reply" ] && [ -z "$jobs_style_query_buffer" ]; then
                    jobs_style_reply=$jobs_style_query_target_reply
                    jobs_style_normalized=$jobs_style_query_target_normalized
                    jobs_style_rgb=$jobs_style_query_target_rgb
                    return 0
                fi
            done
            # 残缺帧不能通过重发拼成另一个答复，更不能被当成键盘空输入。
            if [ -n "$jobs_style_query_buffer" ]; then
                jobs_style_query_failure='配色答复帧不完整，已停止自动恢复'
                return 1
            fi
        done
        return 1
    }
    # 查询可用不代表终端允许改色，按目标值核对实际生效结果。
    jobs_terminal_style_accepts_target() {
        jobs_style_requested_hex=''
        case $1 in
            10|12) jobs_style_requested_hex=ffffff ;;
            11) jobs_style_requested_hex=000000 ;;
            '4;'*)
                jobs_style_requested_index=0
                for jobs_style_requested_color in 000000 ff5f56 5fd787 ffd75f 5fafff d787ff 5fd7ff eeeeee 9e9e9e ff8787 87ffaf ffff87 87bfff ffafff afffff ffffff; do
                    if [ "4;$jobs_style_requested_index" = "$1" ]; then
                        jobs_style_requested_hex=$jobs_style_requested_color
                        break
                    fi
                    jobs_style_requested_index=$((jobs_style_requested_index + 1))
                done
                ;;
        esac
        [ -n "$jobs_style_requested_hex" ] || return 1
        printf '%s|%s\n' "$jobs_style_normalized" "$jobs_style_requested_hex" | LC_ALL=C awk -F'|' '
            function hexbyte(h) {
                return (index("0123456789abcdef", substr(h, 1, 1)) - 1) * 16 + index("0123456789abcdef", substr(h, 2, 1)) - 1
            }
            {
                if (split($1, actual, "/") != 3 || length($2) != 6) exit 1
                for (i = 1; i <= 3; i++) {
                    difference = actual[i] - hexbyte(substr($2, i * 2 - 1, 2)) * 257
                    if (difference < -255 || difference > 255) exit 1
                }
            }
        '
    }
    # 核验中断时重新读取当前值，只撤回仍等于本轮目标值的颜色。
    jobs_terminal_style_rollback() {
        jobs_style_rollback_issue='无法读取或设置原终端输入模式'
        jobs_style_rollback_safe=''
        jobs_style_rollback_conflicts=''
        jobs_style_phase_control_keys=0
        jobs_style_stty=$(stty -g 2>/dev/null < /dev/tty) || jobs_style_stty=''
        if [ -n "$jobs_style_stty" ] && stty -echo -icanon min 0 time 1 2>/dev/null < /dev/tty; then
            jobs_style_query_active=1
            jobs_style_rollback_ok=1
            while IFS='|' read -r jobs_style_key jobs_style_original_normalized jobs_style_original; do
                [ -n "$jobs_style_key" ] || continue
                if ! jobs_terminal_style_query "$jobs_style_key" cleanup; then
                    jobs_style_rollback_ok=0
                    jobs_style_rollback_issue="回退颜色项 $jobs_style_key：$jobs_style_query_failure"
                    break
                fi
                if [ "$jobs_style_normalized" = "$jobs_style_original_normalized" ]; then
                    continue
                elif jobs_terminal_style_accepts_target "$jobs_style_key"; then
                    jobs_style_rollback_safe=$jobs_style_rollback_safe$jobs_style_original
                else
                    jobs_style_rollback_conflicts="$jobs_style_rollback_conflicts $jobs_style_key"
                fi
            done <<JOBS_STYLE_ROLLBACK
$jobs_style_original_rows
JOBS_STYLE_ROLLBACK
            stty "$jobs_style_stty" 2>/dev/null < /dev/tty || { jobs_style_rollback_ok=0; jobs_style_rollback_issue='无法恢复原终端输入模式'; }
            jobs_style_query_active=0
            if [ "$jobs_style_rollback_ok" = 1 ] && printf '%s\033[0m' "$jobs_style_rollback_safe" > /dev/tty; then
                if [ -z "$jobs_style_rollback_conflicts" ]; then
                    rm -f "$jobs_style_recovery"
                    rmdir "${jobs_style_recovery%/*}" 2>/dev/null || :
                    return 0
                fi
                printf '检测到运行期间的配色变更，已保留这些项：%s\n' "$jobs_style_rollback_conflicts" >&2
                jobs_style_rollback_issue="核验中断后检测到其它配色变更：$jobs_style_rollback_conflicts"
            fi
        fi
        printf '终端配色未能安全自动恢复（%s）；确认覆盖当前配色后可运行：sh "%s"\n' "$jobs_style_rollback_issue" "$jobs_style_recovery" >&2
        return 1
    }
    # 检测到后续改色时只恢复仍由本次保护持有的项，保留独立恢复入口。
    jobs_terminal_style_cleanup() {
        jobs_style_result=$1
        trap '' HUP INT TERM
        if [ "$jobs_style_query_active" = 1 ]; then
            stty "$jobs_style_stty" 2>/dev/null < /dev/tty || :
            jobs_style_query_active=0
        fi
        if [ "$jobs_style_changed" = 1 ] && [ "$jobs_style_applied_complete" != 1 ]; then
            if jobs_terminal_style_rollback; then
                jobs_style_changed=0
            else
                [ "$jobs_style_result" -ne 0 ] || jobs_style_result=1
            fi
            if [ "${2:-}" = continue ]; then
                jobs_style_cleanup_status=$jobs_style_result
                return 0
            fi
            exit "$jobs_style_result"
        fi
        if [ "$jobs_style_changed" = 1 ]; then
            jobs_style_cleanup_ok=0
            jobs_style_cleanup_issue='无法读取或设置原终端输入模式，或临时配色未完成核验'
            jobs_style_conflicts=''
            jobs_style_restore_safe=''
            jobs_style_phase_control_keys=0
            if [ "$jobs_style_applied_complete" = 1 ]; then
                jobs_style_stty=$(stty -g 2>/dev/null < /dev/tty) || jobs_style_stty=''
                if [ -n "$jobs_style_stty" ] && stty -echo -icanon min 0 time 1 2>/dev/null < /dev/tty; then
                    jobs_style_query_active=1
                    jobs_style_cleanup_ok=1
                    while IFS='|' read -r jobs_style_key jobs_style_expected jobs_style_original; do
                        [ -n "$jobs_style_key" ] || continue
                        if ! jobs_terminal_style_query "$jobs_style_key" cleanup; then
                            jobs_style_cleanup_ok=0
                            jobs_style_cleanup_issue="颜色项 $jobs_style_key：$jobs_style_query_failure"
                            break
                        fi
                        if [ "$jobs_style_normalized" = "$jobs_style_expected" ]; then
                            jobs_style_restore_safe=$jobs_style_restore_safe$jobs_style_original
                        else
                            jobs_style_conflicts="$jobs_style_conflicts $jobs_style_key"
                        fi
                    done <<JOBS_STYLE_APPLIED
$jobs_style_applied_rows
JOBS_STYLE_APPLIED
                    stty "$jobs_style_stty" 2>/dev/null < /dev/tty || { jobs_style_cleanup_ok=0; jobs_style_cleanup_issue='无法恢复原终端输入模式'; }
                    jobs_style_query_active=0
                fi
            fi
            if [ "$jobs_style_cleanup_ok" = 1 ] && printf '%s\033[0m' "$jobs_style_restore_safe" > /dev/tty; then
                if [ -z "$jobs_style_conflicts" ]; then
                    rm -f "$jobs_style_recovery"
                    rmdir "${jobs_style_recovery%/*}" 2>/dev/null || :
                else
                    printf '检测到运行期间的配色变更，已保留这些项：%s\n' "$jobs_style_conflicts" >&2
                    printf '确认要覆盖后续改色时才使用恢复入口：sh "%s"\n' "$jobs_style_recovery" >&2
                    [ "$jobs_style_result" -ne 0 ] || jobs_style_result=1
                fi
            else
                printf '终端配色未能安全自动恢复（%s）；确认覆盖当前配色后可运行：sh "%s"\n' "$jobs_style_cleanup_issue" "$jobs_style_recovery" >&2
                [ "$jobs_style_result" -ne 0 ] || jobs_style_result=1
            fi
        fi
        if [ "${2:-}" = continue ]; then
            jobs_style_cleanup_status=$jobs_style_result
            return 0
        fi
        exit "$jobs_style_result"
    }
    trap 'jobs_terminal_style_cleanup "$jobs_style_exit_status"' 0
    trap 'jobs_style_exit_status=129; jobs_terminal_style_cleanup 129 continue; jobs_style_changed=0; exit 129' HUP
    trap 'jobs_style_exit_status=130; jobs_terminal_style_cleanup 130 continue; jobs_style_changed=0; exit 130' INT
    trap 'jobs_style_exit_status=143; jobs_terminal_style_cleanup 143 continue; jobs_style_changed=0; exit 143' TERM
    if ! stty -echo -icanon min 0 time 1 2>/dev/null < /dev/tty; then
        jobs_terminal_style_plain "$@"
    fi
    jobs_style_query_active=1
    jobs_style_probe_ok=1
    for jobs_style_key in 10 11 12 '4;0' '4;1' '4;2' '4;3' '4;4' '4;5' '4;6' '4;7' '4;8' '4;9' '4;10' '4;11' '4;12' '4;13' '4;14' '4;15'; do
        if ! jobs_terminal_style_query "$jobs_style_key"; then
            jobs_style_probe_ok=0
            break
        fi
        jobs_style_saved=$jobs_style_saved$jobs_style_reply
        jobs_style_original_rows="$jobs_style_original_rows$jobs_style_key|$jobs_style_normalized|$jobs_style_reply
"
        jobs_style_saved_rows="$jobs_style_saved_rows$jobs_style_key|$jobs_style_reply
"
    done
    stty "$jobs_style_stty" 2>/dev/null < /dev/tty || { jobs_style_exit_status=1; exit 1; }
    jobs_style_query_active=0
    if [ "$jobs_style_probe_ok" != 1 ]; then
        printf '%s\n' '终端不支持完整配色保存，或启动时收到其它输入；保留原配色并使用纯文本。' >&2
        jobs_terminal_style_plain "$@"
    fi
    jobs_style_recovery_dir=$(umask 077; mktemp -d "${TMPDIR:-/tmp}/jobs-terminal-style.XXXXXX") || jobs_terminal_style_plain "$@"
    jobs_style_recovery=$jobs_style_recovery_dir/restore.sh
    if ! (umask 077; {
        printf '#!/bin/sh\n'
        printf '[ -t 0 ] && [ "$(tty)" = '\''%s'\'' ] || { printf '\''请在原终端运行恢复入口。\\n'\'' >&2; exit 1; }\n' "$jobs_style_tty"
        printf 'printf '\''本操作会覆盖此终端当前配色。确认恢复脚本启动前的配色，请输入 YES：'\'' >&2\n'
        printf 'IFS= read -r jobs_restore_choice\n[ "$jobs_restore_choice" = YES ] || exit 1\n'
        printf 'printf '\''%%s\\033[0m'\'' '\''%s'\'' > /dev/tty\n' "$jobs_style_saved"
    } > "$jobs_style_recovery"); then
        printf '%s\n' '无法保存终端配色恢复入口；保留原配色并使用纯文本。' >&2
        jobs_terminal_style_plain "$@"
    fi
    printf '正在准备本次终端临时配色；强退后恢复入口：sh "%s"\n' "$jobs_style_recovery" >&2
    jobs_style_changed=1
    printf '\033]10;#ffffff\007\033]11;#000000\007\033]12;#ffffff\007' > /dev/tty
    jobs_style_index=0
    for jobs_style_color in 000000 ff5f56 5fd787 ffd75f 5fafff d787ff 5fd7ff eeeeee 9e9e9e ff8787 87ffaf ffff87 87bfff ffafff afffff ffffff; do
        printf '\033]4;%s;#%s\007' "$jobs_style_index" "$jobs_style_color" > /dev/tty
        jobs_style_index=$((jobs_style_index + 1))
    done
    printf '\033[0m' > /dev/tty
    jobs_style_stty=$(stty -g 2>/dev/null < /dev/tty) || { jobs_style_exit_status=1; exit 1; }
    stty -echo -icanon min 0 time 1 2>/dev/null < /dev/tty || { jobs_style_exit_status=1; exit 1; }
    jobs_style_query_active=1
    jobs_style_probe_ok=1
    jobs_style_targets_ok=1
    jobs_style_phase_control_keys=0
    while IFS='|' read -r jobs_style_key jobs_style_original; do
        [ -n "$jobs_style_key" ] || continue
        if ! jobs_terminal_style_query "$jobs_style_key" applied; then
            jobs_style_probe_ok=0
            break
        fi
        jobs_style_applied_rows="$jobs_style_applied_rows$jobs_style_key|$jobs_style_normalized|$jobs_style_original
"
        if ! jobs_terminal_style_accepts_target "$jobs_style_key"; then
            jobs_style_targets_ok=0
        fi
    done <<JOBS_STYLE_ORIGINAL
$jobs_style_saved_rows
JOBS_STYLE_ORIGINAL
    stty "$jobs_style_stty" 2>/dev/null < /dev/tty || { jobs_style_exit_status=1; exit 1; }
    jobs_style_query_active=0
    if [ "$jobs_style_probe_ok" != 1 ]; then
        printf '临时配色核验失败（颜色项 %s：%s），正在核对原色恢复。\n' "$jobs_style_key" "$jobs_style_query_failure" >&2
        jobs_terminal_style_cleanup 0 continue
        jobs_style_changed=0
        if [ "$jobs_style_cleanup_status" != 0 ]; then
            jobs_style_exit_status=1
            exit 1
        fi
        trap 'jobs_style_exit_status=129; jobs_terminal_style_cleanup 129 continue; jobs_style_changed=0; exit 129' HUP
        trap 'jobs_style_exit_status=130; jobs_terminal_style_cleanup 130 continue; jobs_style_changed=0; exit 130' INT
        trap 'jobs_style_exit_status=143; jobs_terminal_style_cleanup 143 continue; jobs_style_changed=0; exit 143' TERM
        printf '%s\n' '已恢复原配色并使用纯文本。' >&2
        jobs_terminal_style_plain "$@"
    fi
    if [ "$jobs_style_targets_ok" != 1 ]; then
        jobs_terminal_style_cleanup 0 continue
        jobs_style_changed=0
        if [ "$jobs_style_cleanup_status" != 0 ]; then
            jobs_style_exit_status=1
            exit 1
        fi
        trap 'jobs_style_exit_status=129; jobs_terminal_style_cleanup 129 continue; jobs_style_changed=0; exit 129' HUP
        trap 'jobs_style_exit_status=130; jobs_terminal_style_cleanup 130 continue; jobs_style_changed=0; exit 130' INT
        trap 'jobs_style_exit_status=143; jobs_terminal_style_cleanup 143 continue; jobs_style_changed=0; exit 143' TERM
        printf '%s\n' '终端未接受本次配色，已恢复原配色并使用纯文本。' >&2
        jobs_terminal_style_plain "$@"
    fi
    jobs_style_applied_complete=1
    printf '%s\n' '本次终端已临时使用黑底白字。' >&2
    JOBS_TERMINAL_STYLE_TTY=$jobs_style_tty
    JOBS_TERMINAL_STYLE_OWNER=$$
    export JOBS_TERMINAL_STYLE_TTY JOBS_TERMINAL_STYLE_OWNER
    if "$@"; then
        jobs_style_exit_status=0
    else
        jobs_style_exit_status=$?
    fi
    exit "$jobs_style_exit_status"
}
# 仅监督直接执行的入口；被 source 时不切换配色、不重新执行业务。
jobs_terminal_style_bootstrap() {
    jobs_style_bootstrap_script=$1
    shift
    if [ -n "${ZSH_VERSION:-}" ]; then
        case ${ZSH_EVAL_CONTEXT:-} in
            *:file|*:file:*) return 0 ;;
        esac
    elif [ -n "${BASH_VERSION:-}" ] && [ "${BASH_SOURCE:-$jobs_style_bootstrap_script}" != "$jobs_style_bootstrap_script" ]; then
        return 0
    fi
    if [ "${JOBS_TERMINAL_STYLE_REEXEC:-}" = "$jobs_style_bootstrap_script" ]; then
        unset JOBS_TERMINAL_STYLE_REEXEC
        return 0
    fi
    if [ ! -t 0 ] || [ ! -t 1 ] || [ -z "${TERM:-}" ] ||
       [ "${TERM:-}" = dumb ] || [ "${NO_COLOR+x}" = x ] ||
       [ "${PLAIN_OUTPUT:-0}" = 1 ] || [ "${IS_SOURCETREE_RUNTIME:-0}" = 1 ] ||
       [ -n "${TMUX:-}${STY:-}" ] ||
       env | LC_ALL=C grep -qiE '^(SOURCETREE|SOURCE_TREE)'; then
        return 0
    fi
    case ${JOBS_TERMINAL_STYLE_OWNER:-} in
        ''|*[!0-9]*) ;;
        *)
            if kill -0 "$JOBS_TERMINAL_STYLE_OWNER" 2>/dev/null &&
               [ "${JOBS_TERMINAL_STYLE_TTY:-}" = "$(tty 2>/dev/null)" ]; then
                return 0
            fi
            ;;
    esac
    JOBS_TERMINAL_STYLE_REEXEC=$jobs_style_bootstrap_script
    export JOBS_TERMINAL_STYLE_REEXEC
    jobs_terminal_style_run /bin/zsh "$jobs_style_bootstrap_script" "$@"
    jobs_style_bootstrap_result=$?
    exit "$jobs_style_bootstrap_result"
}
jobs_terminal_style_bootstrap "$0" "$@"
# <<< Jobs terminal style protection v1 <<<

TEST_SCRIPT_DIR="${${(%):-%x}:A:h:h}"
TEST_ROOT=''
TEST_COUNT=0
TEST_FAILED=0
TEST_QUARANTINE_BODY=''
TEST_GLOBAL_FLUTTER_BODY=''

# 只清理本测试自己创建的目录。
cleanup_tests() {
  if [[ -n "$TEST_ROOT" && -d "$TEST_ROOT" && "${TEST_ROOT:t}" == .jobs-flutter-gem-tests.* ]]; then
    /bin/rm -r -- "$TEST_ROOT"
  fi
}
# 在整个测试进程结束时清理，避免 zsh 的函数内 EXIT trap 提前触发。
TRAPEXIT() {
  cleanup_tests
}
# 使用 HOME 内的临时根验证真实的用户目录范围检查，不修改 HOME。
initialize_tests() {
  setopt NO_NOMATCH
  print -r -- 'Flutter / Gem 隔离回归：只运行假命令；不联网、不安装、不升级。'
  TEST_ROOT="$(/usr/bin/mktemp -d "$HOME/.jobs-flutter-gem-tests.XXXXXXXX")" || return 1
  export JOBS_MAC_ENV_SOURCE_MODE=1
  source "${TEST_SCRIPT_DIR:h}/【MacOS】update.command" || return 1
  TEST_QUARANTINE_BODY="${functions[jobs_update_flutter_release_verified_quarantine]}"
  TEST_GLOBAL_FLUTTER_BODY="${functions[jobs_update_find_global_flutter]}"
}
# 每个用例有独立目录；所有命令均明确替换，避免调用宿主工具链。
reset_fixture() {
  export TEST_CASE_DIR="$TEST_ROOT/case-$TEST_COUNT"
  export TEST_CASE_CALLS="$TEST_CASE_DIR/calls"
  /bin/mkdir -p "$TEST_CASE_DIR/shared/plugins" "$TEST_CASE_DIR/shared/bin" "$TEST_CASE_DIR/user/bin" "$TEST_CASE_DIR/sdk/bin"
  : > "$TEST_CASE_CALLS"
  LOG_FILE="$TEST_CASE_DIR/log"
  : > "$LOG_FILE"
  export MOCK_UPGRADE_RESULT=0 MOCK_DOCTOR_RESULT=0 MOCK_DOCTOR_LICENSE=0 MOCK_DOCTOR_ERROR_OUTPUT=0 MOCK_GEM_RESULT=0 MOCK_USER_VISIBLE=1 MOCK_POST_USER_VISIBLE=1
  MOCK_RUBY_PATH='/opt/homebrew/Cellar/ruby/4.0.9/bin/ruby'
  MOCK_GEM_HOME="$TEST_CASE_DIR/shared"
  MOCK_GEM_BIN="$TEST_CASE_DIR/shared/bin"
  MOCK_GEM_USER="$TEST_CASE_DIR/user"
  MOCK_FLUTTER="$TEST_CASE_DIR/sdk/bin/flutter"
  FVM_CACHE_PATH="$TEST_CASE_DIR/fvm"
  unset FVM_HOME FLUTTER_ROOT FLUTTER_HOME
  export PATH='/usr/bin:/bin:/usr/sbin:/sbin'
  JOBS_UPDATE_TRUST_MODE=1
  /bin/cat > "$MOCK_FLUTTER" <<'MOCK_FLUTTER_SCRIPT'
#!/bin/zsh
print -r -- "flutter|$*" >> "$TEST_CASE_CALLS"
case "$*" in
  upgrade)
    print -r -- "upgrade-cwd|$PWD" >> "$TEST_CASE_CALLS"
    exit "$MOCK_UPGRADE_RESULT"
    ;;
  'doctor -v')
    [[ "$MOCK_DOCTOR_LICENSE" != 1 ]] || print -r -- 'Android license status unknown. Run flutter doctor --android-licenses.'
    if (( MOCK_DOCTOR_RESULT != 0 || MOCK_DOCTOR_ERROR_OUTPUT == 1 )); then
      print -r -- 'Failed to download sky_engine.zip. SocketException: Connection refused'
    fi
    exit "$MOCK_DOCTOR_RESULT"
    ;;
  'doctor --android-licenses') exit 0 ;;
  *) exit 98 ;;
esac
MOCK_FLUTTER_SCRIPT
  /bin/chmod +x "$MOCK_FLUTTER"
  # 网络策略由独立SDK夹具验证；本回归只执行已限定的假Flutter，避免触碰真实网络。
  function jobs_flutter_sdk_command() { "$@"; }
  function jobs_update_has() { return 1; }
  function jobs_update_find_external_command() {
    [[ "$1" == flutter ]] || return 1
    print -r -- "$MOCK_FLUTTER"
  }
  function jobs_update_find_global_flutter() { print -r -- "$MOCK_FLUTTER"; }
  function jobs_update_flutter_release_verified_quarantine() { print -r -- 'quarantine' >> "$TEST_CASE_CALLS"; }
  function jobs_update_repair_gem_extensions() { return 0; }
  function jobs_gemext_find_ruby() { print -r -- "$MOCK_RUBY_PATH"; }
  function jobs_update_gem() {
    print -r -- "gem|$*" >> "$TEST_CASE_CALLS"
    case "$*" in
      env)
        print -r -- "  - INSTALLATION DIRECTORY: $MOCK_GEM_HOME"
        print -r -- "  - EXECUTABLE DIRECTORY: $MOCK_GEM_BIN"
        print -r -- "  - RUBY EXECUTABLE: $MOCK_RUBY_PATH"
        ;;
      'env user_gemhome') print -r -- "$MOCK_GEM_USER" ;;
      'env path')
        local visible="$MOCK_USER_VISIBLE"
        [[ ! -f "$TEST_CASE_DIR/gem-updated" ]] || visible="$MOCK_POST_USER_VISIBLE"
        if (( visible == 1 )); then
          print -r -- "$MOCK_GEM_HOME:$MOCK_GEM_USER"
        else
          print -r -- "$MOCK_GEM_HOME"
        fi
        ;;
      update*)
        if [[ " $* " != *' --no-document '* ]]; then
          print -u2 -r -- 'ERROR: RDoc NoMethodError while generating ri documentation'
          return 1
        fi
        : > "$TEST_CASE_DIR/gem-updated"
        return "$MOCK_GEM_RESULT"
        ;;
      *) return 97 ;;
    esac
  }
}
# 精确检查模拟调用，避免匹配描述行造成假通过。
assert_call() {
  /usr/bin/grep -Fxq -- "$1" "$TEST_CASE_CALLS" || {
    print -u2 -r -- "缺少调用：$1"
    /bin/cat "$TEST_CASE_CALLS" >&2
    return 1
  }
}
# 确认失败分支没有继续执行后续写操作。
assert_no_call() {
  if /usr/bin/grep -Fq -- "$1" "$TEST_CASE_CALLS"; then
    print -u2 -r -- "不应出现调用：$1"
    return 1
  fi
}
# 在共享 home 可写时保留原安装来源和明确验证的写入位置。
test_gem_shared() {
  jobs_update_gem_packages 'gem update' || return 1
  assert_call "gem|update --no-user-install --install-dir $MOCK_GEM_HOME --bindir $MOCK_GEM_BIN --no-document" || return 1
  assert_no_call '--user-install --bindir'
}
# 复现日志中的只读 rdoc 插件；必须回退用户目录而不是发起 sudo。
test_gem_readonly_plugin() {
  print -r -- 'old plugin' > "$MOCK_GEM_HOME/plugins/rdoc_plugin.rb"
  /bin/chmod 400 "$MOCK_GEM_HOME/plugins/rdoc_plugin.rb"
  jobs_update_gem_packages 'gem update' || return 1
  assert_call "gem|update --user-install --bindir $MOCK_GEM_USER/bin --no-document" || return 1
  [[ ":$PATH:" == *":$MOCK_GEM_USER/bin:"* ]] || return 1
  [[ "$(/bin/cat "$MOCK_GEM_HOME/plugins/rdoc_plugin.rb")" == 'old plugin' ]] || return 1
  assert_no_call 'sudo'
}
# 当前 Ruby 搜索不到用户目录时，不能安装后再误报可用。
test_gem_user_not_visible() {
  /bin/chmod 500 "$MOCK_GEM_HOME/plugins"
  MOCK_USER_VISIBLE=0
  local result=0
  jobs_update_gem_packages 'gem update' || result=$?
  /bin/chmod 700 "$MOCK_GEM_HOME/plugins"
  (( result != 0 )) || return 1
  assert_no_call 'gem|update'
}
# 用户 Gem 目录仍不可写时明确失败，不扩大权限。
test_gem_user_not_writable() {
  /bin/chmod 500 "$MOCK_GEM_HOME/plugins" "$MOCK_GEM_USER/bin"
  local result=0
  jobs_update_gem_packages 'gem update' || result=$?
  /bin/chmod 700 "$MOCK_GEM_HOME/plugins" "$MOCK_GEM_USER/bin"
  (( result != 0 )) || return 1
  assert_no_call 'gem|update'
}
# 用户升级失败或升级后 Ruby 搜索路径失效，必须传播失败且不前置 PATH。
test_gem_user_failure() {
  /bin/chmod 500 "$MOCK_GEM_HOME/plugins"
  MOCK_GEM_RESULT=7
  local result=0 original_path="$PATH"
  jobs_update_gem_packages 'gem update' || result=$?
  /bin/chmod 700 "$MOCK_GEM_HOME/plugins"
  (( result == 7 )) && [[ "$PATH" == "$original_path" ]]
}
# 用户 bin 不能通过符号链接重新写到共享目录。
test_gem_user_symlink() {
  /bin/chmod 500 "$MOCK_GEM_HOME/plugins"
  /bin/rmdir "$MOCK_GEM_USER/bin"
  /bin/ln -s "$MOCK_GEM_BIN" "$MOCK_GEM_USER/bin"
  local result=0
  jobs_update_gem_packages 'gem update' || result=$?
  /bin/chmod 700 "$MOCK_GEM_HOME/plugins"
  (( result != 0 )) || return 1
  assert_no_call 'gem|update'
}
# 更新完成但当前 Ruby 搜索范围发生变化时，仍然明确返回失败。
test_gem_post_visibility() {
  /bin/chmod 500 "$MOCK_GEM_HOME/plugins"
  MOCK_POST_USER_VISIBLE=0
  local result=0 original_path="$PATH"
  jobs_update_gem_packages 'gem update' || result=$?
  /bin/chmod 700 "$MOCK_GEM_HOME/plugins"
  (( result != 0 )) && [[ "$PATH" == "$original_path" ]]
}
# 用户 Gem 回退加入 PATH 后，已有 Homebrew pod 不能被用户 bin 抢占。
test_gem_preserves_active_pod() {
  /bin/mkdir -p "$TEST_CASE_DIR/brew-bin"
  print -r -- '#!/bin/zsh' > "$TEST_CASE_DIR/brew-bin/pod"
  print -r -- '#!/bin/zsh' > "$MOCK_GEM_USER/bin/pod"
  /bin/chmod +x "$TEST_CASE_DIR/brew-bin/pod" "$MOCK_GEM_USER/bin/pod"
  export PATH="$TEST_CASE_DIR/brew-bin:$PATH"
  /bin/chmod 500 "$MOCK_GEM_HOME/plugins"
  jobs_update_gem_packages 'gem update' || return 1
  /bin/chmod 700 "$MOCK_GEM_HOME/plugins"
  [[ "$(whence -p pod)" == "$TEST_CASE_DIR/brew-bin/pod" ]]
}
# RubyGems 本体由 Homebrew 管理时，不执行 gem update --system。
test_brew_rubygems() {
  jobs_update_rubygems_system || return 1
  assert_no_call 'gem|update --system'
}
# 子命令失败必须使 Ruby 更新项失败，扩展复检成功不能覆盖它。
test_ruby_result() {
  function jobs_update_has() { [[ "$1" == gem ]]; }
  MOCK_GEM_RESULT=8
  local result=0
  jobs_update_ruby_base || result=$?
  (( result != 0 ))
}
# 独立 SDK 升级失败后不运行 quarantine 或 doctor。
test_flutter_upgrade_failure() {
  MOCK_UPGRADE_RESULT=1
  local result=0
  jobs_update_fvm_flutter || result=$?
  (( result != 0 )) || return 1
  assert_call 'flutter|upgrade' || return 1
  assert_no_call 'quarantine' || return 1
  assert_no_call 'flutter|doctor'
}
# 全局升级不得处理调用方工程依赖，也不能改变调用方工作目录。
test_flutter_upgrade_directory() {
  local project_dir="$TEST_CASE_DIR/project"
  /bin/mkdir -p "$project_dir"
  builtin cd "$project_dir" || return 1
  jobs_update_fvm_flutter || return 1
  assert_call "upgrade-cwd|${MOCK_FLUTTER:h:h}" || return 1
  [[ "$PWD" == "$project_dir" ]]
}
# 恢复生产解析器本体；发现过程使用隔离 PATH，不执行候选 SDK。
use_real_flutter_resolver() {
  [[ -n "$TEST_GLOBAL_FLUTTER_BODY" ]] || return 1
  functions[jobs_update_find_global_flutter]="$TEST_GLOBAL_FLUTTER_BODY"
}
# 仅建立解析器所需的 SDK 身份文件，不下载组件。
create_flutter_sdk_fixture() {
  local sdk_root="$1"
  /bin/mkdir -p "$sdk_root/bin/internal" "$sdk_root/packages/flutter_tools"
  [[ "$sdk_root/bin/flutter" == "$MOCK_FLUTTER" ]] || /bin/cp "$MOCK_FLUTTER" "$sdk_root/bin/flutter" || return 1
  : > "$sdk_root/bin/internal/shared.sh"
  : > "$sdk_root/bin/internal/engine.version"
  : > "$sdk_root/packages/flutter_tools/pubspec.yaml"
}
# FVM default 指向固定版本时，原缓存不被直接 upgrade 或 doctor 改写。
test_fvm_pinned() {
  create_flutter_sdk_fixture "$FVM_CACHE_PATH/versions/3.38.0" || return 1
  /bin/ln -s "$FVM_CACHE_PATH/versions/3.38.0" "$FVM_CACHE_PATH/default"
  export PATH="$FVM_CACHE_PATH/default/bin:$PATH"
  use_real_flutter_resolver || return 1
  jobs_update_fvm_flutter || return 1
  assert_no_call 'flutter|'
}
# FVM global 的频道缓存可能与项目共享，同样保留原缓存。
test_fvm_channel() {
  create_flutter_sdk_fixture "$FVM_CACHE_PATH/versions/stable" || return 1
  /bin/ln -s "$FVM_CACHE_PATH/versions/stable" "$FVM_CACHE_PATH/default"
  export PATH="$FVM_CACHE_PATH/default/bin:$PATH"
  use_real_flutter_resolver || return 1
  jobs_update_fvm_flutter || return 1
  assert_no_call 'flutter|'
}
# 工程 FVM 在 PATH 前面时仍能继续发现独立全局 SDK。
test_flutter_project_before_global() {
  local project_sdk="$TEST_CASE_DIR/project/.fvm/flutter_sdk"
  create_flutter_sdk_fixture "$project_sdk" || return 1
  create_flutter_sdk_fixture "${MOCK_FLUTTER:h:h}" || return 1
  export PATH="$project_sdk/bin:${MOCK_FLUTTER:h}:$PATH"
  use_real_flutter_resolver || return 1
  [[ "$(jobs_update_find_global_flutter)" == "${MOCK_FLUTTER:A}" ]] || return 1
  [[ ! -s "$TEST_CASE_CALLS" ]] || return 1
  jobs_update_fvm_flutter || return 1
  assert_call 'flutter|upgrade' || return 1
  assert_call 'flutter|doctor -v'
}
# 没有 Flutter 或 FVM 时正常跳过，不能为了更新先安装。
test_flutter_absent() {
  use_real_flutter_resolver || return 1
  jobs_update_fvm_flutter || return 1
  [[ ! -s "$TEST_CASE_CALLS" ]]
}
# 只有 FVM 工具不代表已安装独立全局 Flutter。
test_flutter_fvm_only() {
  function jobs_update_has() { [[ "$1" == fvm ]]; }
  use_real_flutter_resolver || return 1
  jobs_update_fvm_flutter || return 1
  [[ ! -s "$TEST_CASE_CALLS" ]]
}
# 只有 Dart 时不能通过 pub activate 顺手安装 FVM。
test_flutter_dart_without_fvm() {
  function jobs_update_has() { [[ "$1" == dart ]]; }
  function dart() { print -r -- "dart|$*" >> "$TEST_CASE_CALLS"; }
  use_real_flutter_resolver || return 1
  jobs_update_fvm_flutter || return 1
  assert_no_call 'dart|pub global activate fvm' || return 1
  assert_no_call 'flutter|'
}
# 已安装的 Dart pub FVM 继续维护工具本体，不隐式安装 SDK。
test_flutter_existing_pub_fvm() {
  function jobs_update_has() { [[ "$1" == dart || "$1" == fvm ]]; }
  function dart() { print -r -- "dart|$*" >> "$TEST_CASE_CALLS"; }
  use_real_flutter_resolver || return 1
  jobs_update_fvm_flutter || return 1
  assert_call 'dart|pub global activate fvm' || return 1
  assert_no_call 'flutter|'
}
# FLUTTER_ROOT 提供的独立 SDK 不要求预先出现在 PATH。
test_flutter_root_environment() {
  create_flutter_sdk_fixture "${MOCK_FLUTTER:h:h}" || return 1
  export FLUTTER_ROOT="${MOCK_FLUTTER:h:h}"
  use_real_flutter_resolver || return 1
  [[ "$(jobs_update_find_global_flutter)" == "${MOCK_FLUTTER:A}" ]] || return 1
  [[ ! -s "$TEST_CASE_CALLS" ]]
}
# FLUTTER_HOME 同样可以定位已有 SDK，并拒绝被声明成全局的 FVM 缓存。
test_flutter_home_environment() {
  create_flutter_sdk_fixture "${MOCK_FLUTTER:h:h}" || return 1
  export FLUTTER_HOME="${MOCK_FLUTTER:h:h}"
  use_real_flutter_resolver || return 1
  [[ "$(jobs_update_find_global_flutter)" == "${MOCK_FLUTTER:A}" ]] || return 1
  create_flutter_sdk_fixture "$FVM_CACHE_PATH/versions/stable" || return 1
  export FLUTTER_HOME="$FVM_CACHE_PATH/versions/stable"
  ! jobs_update_find_global_flutter >/dev/null
}
# Homebrew SDK 不在 PATH 时，只读查询前缀发现，不能调用真实 brew。
test_flutter_brew_discovery() {
  local brew_prefix="$TEST_CASE_DIR/brew-prefix"
  create_flutter_sdk_fixture "$brew_prefix/share/flutter" || return 1
  export MOCK_BREW_PREFIX="$brew_prefix"
  function jobs_update_has() { [[ "$1" == brew ]]; }
  function brew() {
    print -r -- "brew|$*" >> "$TEST_CASE_CALLS"
    [[ "$*" == --prefix ]] || return 97
    print -r -- "$MOCK_BREW_PREFIX"
  }
  use_real_flutter_resolver || return 1
  [[ "$(jobs_update_find_global_flutter)" == "$brew_prefix/share/flutter/bin/flutter" ]] || return 1
  assert_call 'brew|--prefix' || return 1
  assert_no_call 'flutter|' || return 1
  assert_no_call 'brew|install'
}
# 跳过 PATH 中的 shim；解析身份时不执行任何候选命令。
test_flutter_wrapper_not_executed() {
  local wrapper_dir="$TEST_CASE_DIR/wrapper"
  /bin/mkdir -p "$wrapper_dir"
  /bin/cat > "$wrapper_dir/flutter" <<'MOCK_FLUTTER_WRAPPER'
#!/bin/zsh
print -r -- "wrapper|$*" >> "$TEST_CASE_CALLS"
exit 99
MOCK_FLUTTER_WRAPPER
  /bin/chmod +x "$wrapper_dir/flutter"
  create_flutter_sdk_fixture "${MOCK_FLUTTER:h:h}" || return 1
  export PATH="$wrapper_dir:${MOCK_FLUTTER:h}:$PATH"
  use_real_flutter_resolver || return 1
  [[ "$(jobs_update_find_global_flutter)" == "${MOCK_FLUTTER:A}" ]] || return 1
  [[ ! -s "$TEST_CASE_CALLS" ]]
}
# 符号链接指向独立 SDK 可识别，缺少 SDK 身份的文件不能被升级。
test_flutter_symlink_and_incomplete_sdk() {
  local link_dir="$TEST_CASE_DIR/linked-bin"
  /bin/mkdir -p "$link_dir"
  create_flutter_sdk_fixture "${MOCK_FLUTTER:h:h}" || return 1
  /bin/ln -s "$MOCK_FLUTTER" "$link_dir/flutter"
  export PATH="$link_dir:$PATH"
  use_real_flutter_resolver || return 1
  [[ "$(jobs_update_find_global_flutter)" == "${MOCK_FLUTTER:A}" ]] || return 1
  /bin/rm -- "${MOCK_FLUTTER:h}/internal/shared.sh"
  ! jobs_update_find_global_flutter >/dev/null
}
# doctor 下载失败不能因日志清理或许可提示而变成成功。
test_doctor_failure() {
  MOCK_DOCTOR_RESULT=1
  MOCK_DOCTOR_LICENSE=1
  local result=0
  jobs_update_run_flutter_doctor_and_android_licenses Flutter "$MOCK_FLUTTER" || result=$?
  (( result != 0 )) || return 1
  assert_no_call 'flutter|doctor --android-licenses'
}
# 即使 doctor 返回零，明确的资源下载错误也不能报成功。
test_doctor_false_success() {
  MOCK_DOCTOR_ERROR_OUTPUT=1
  local result=0
  jobs_update_run_flutter_doctor_and_android_licenses Flutter "$MOCK_FLUTTER" || result=$?
  (( result != 0 ))
}
# 仅替换系统依赖，继续执行生产隔离标记函数本体。
install_quarantine_mocks() {
  local quarantine_body="${TEST_QUARANTINE_BODY//\/usr\/bin\/codesign/mock_codesign}"
  quarantine_body="${quarantine_body//\/usr\/bin\/xattr/mock_xattr}"
  eval "jobs_update_flutter_release_verified_quarantine() { $quarantine_body }"
  /bin/mkdir -p "$TEST_CASE_DIR/sdk/bin/cache/dart-sdk/bin"
  /bin/cp "$MOCK_FLUTTER" "$TEST_CASE_DIR/sdk/bin/cache/dart-sdk/bin/dart"
  function mock_codesign() {
    print -r -- 'Authority=Developer ID Application: FLUTTER.IO LLC (S8QB4VV633)'
  }
  function mock_xattr() {
    print -r -- "xattr|$*" >> "$TEST_CASE_CALLS"
  }
  function find() {
    local count=0
    [[ ! -f "$TEST_CASE_DIR/find-count" ]] || count="$(<"$TEST_CASE_DIR/find-count")"
    (( count += 1 ))
    print -r -- "$count" > "$TEST_CASE_DIR/find-count"
    (( count != MOCK_FIND_FAIL_AT )) || return 1
    if (( count == 1 )); then
      print -r -- "$TEST_CASE_DIR/sdk/quarantined-file"
    fi
    return 0
  }
}
# 查询失败不等于 SDK 无隔离标记。
test_quarantine_initial_query_failure() {
  install_quarantine_mocks
  MOCK_FIND_FAIL_AT=1
  local result=0
  jobs_update_flutter_release_verified_quarantine "$MOCK_FLUTTER" || result=$?
  (( result != 0 )) || return 1
  assert_no_call 'xattr|' || return 1
  ! /usr/bin/grep -Fq 'Flutter SDK 无 quarantine 标记' "$LOG_FILE"
}
# 清理后的查询失败也不能输出已全部解除。
test_quarantine_final_query_failure() {
  install_quarantine_mocks
  MOCK_FIND_FAIL_AT=3
  local result=0
  jobs_update_flutter_release_verified_quarantine "$MOCK_FLUTTER" || result=$?
  (( result != 0 )) || return 1
  ! /usr/bin/grep -Fq '并解除 Flutter SDK quarantine 标记' "$LOG_FILE"
}
# 链接查询失败不能被命令替换或空列表掩盖。
test_quarantine_link_query_failure() {
  install_quarantine_mocks
  MOCK_FIND_FAIL_AT=2
  local result=0
  jobs_update_flutter_release_verified_quarantine "$MOCK_FLUTTER" || result=$?
  (( result != 0 ))
}
# 子 shell 隔离 PATH 和函数替换，每个测试都从独立目录开始。
run_case() {
  local label="$1"
  shift
  (( TEST_COUNT += 1 ))
  if (reset_fixture && "$@"); then
    print -r -- "PASS $label"
  else
    print -u2 -r -- "FAIL $label"
    (( TEST_FAILED += 1 ))
  fi
}
# 运行与用户日志直接相关的回归，不触发真实更新入口。
run_tests() {
  run_case '正常 Gem 保留原来源' test_gem_shared
  run_case '只读 rdoc 插件回退用户目录' test_gem_readonly_plugin
  run_case '用户 Gem 不可见时停止' test_gem_user_not_visible
  run_case '用户 bin 不可写时停止' test_gem_user_not_writable
  run_case '用户 Gem 升级失败不激活 PATH' test_gem_user_failure
  run_case '用户 bin 链接越界停止' test_gem_user_symlink
  run_case '用户 Gem 更新后搜索范围复检' test_gem_post_visibility
  run_case '用户回退保留活跃 Brew pod 来源' test_gem_preserves_active_pod
  run_case 'Homebrew RubyGems 本体保留包管理器管理' test_brew_rubygems
  run_case 'Ruby 子步骤失败不被复检覆盖' test_ruby_result
  run_case 'Flutter 升级失败停止后续 SDK 操作' test_flutter_upgrade_failure
  run_case '全局升级脱离当前工程且保留工作目录' test_flutter_upgrade_directory
  run_case 'FVM 固定版本保护' test_fvm_pinned
  run_case 'FVM 频道缓存同样保护' test_fvm_channel
  run_case '工程 FVM 在前仍发现全局 SDK' test_flutter_project_before_global
  run_case '未安装 Flutter 正常跳过' test_flutter_absent
  run_case '只有 FVM 不安装全局 SDK' test_flutter_fvm_only
  run_case '只有 Dart 不安装 FVM' test_flutter_dart_without_fvm
  run_case '只更新已经安装的 pub FVM 工具' test_flutter_existing_pub_fvm
  run_case 'FLUTTER_ROOT 发现已有全局 SDK' test_flutter_root_environment
  run_case 'FLUTTER_HOME 发现及 FVM 保护' test_flutter_home_environment
  run_case 'Homebrew 前缀发现已有全局 SDK' test_flutter_brew_discovery
  run_case 'PATH shim 不执行且继续发现 SDK' test_flutter_wrapper_not_executed
  run_case 'SDK 链接发现及不完整环境跳过' test_flutter_symlink_and_incomplete_sdk
  run_case 'doctor 网络失败传播' test_doctor_failure
  run_case 'doctor 零退出码下载错误仍失败' test_doctor_false_success
  run_case 'SDK 隔离标记初次查询失败' test_quarantine_initial_query_failure
  run_case 'SDK 隔离标记最终复检失败' test_quarantine_final_query_failure
  run_case 'SDK 隔离标记链接查询失败' test_quarantine_link_query_failure
  print -r -- "完成：$TEST_COUNT 项，失败 $TEST_FAILED 项。"
  (( TEST_FAILED == 0 ))
}
# 编排隔离初始化和回归。
main() {
  initialize_tests # 加载函数并建立仅使用模拟命令的隔离环境。
  run_tests # 验证用户日志涉及的错误和必要保护分支。
}

main "$@"
