# [**Ruby**](https://www.ruby-lang.org/) 运行时隔离测试

![Jobs出品，必属精品](https://picsum.photos/1500/400)

[toc]

---

## 🔥 <span id="前言">前言</span>

> 使用假解释器复现 `gem` 仍指向旧系统运行时的环境，验证更新与原生扩展检查使用同一解释器；不联网、不升级真实工具。

## 一、<span id="coverage">覆盖范围</span> <a href="#前言" style="font-size:17px; color:green;"><b>🔼</b></a> <a href="#🔚" style="font-size:17px; color:green;"><b>🔽</b></a>

- 环境查询和更新均绑定所选解释器，忽略 `PATH` 中旧 `gem` 的固定解释器。
- 子命令清除 Bundler 注入，不修改调用进程原环境。
- [**Homebrew**](https://brew.sh/) 管理的 RubyGems 本体不执行 `gem update --system`。
- 环境读取失败、解释器错配和升级失败均停止或返回失败。
- `PATH` 缺少 `gem` 启动器时，已有解释器自带的 RubyGems 仍可维护。

## 二、<span id="usage">运行方式</span> <a href="#前言" style="font-size:17px; color:green;"><b>🔼</b></a> <a href="#🔚" style="font-size:17px; color:green;"><b>🔽</b></a>

在本目录运行，依赖系统 `zsh` 和基础文件工具：

```shell
zsh ./【MacOS】ruby_runtime_tests.zsh
```

脚本自动执行六项用例；按 `Ctrl+C` 取消。调用记录和日志位于专属临时目录，进程结束自动清理；全部通过返回 `0`，任一用例失败返回非零。该测试不代替真实网络和包升级验收。

[返回更新脚本说明](../../README.md)

**终端配色保护：** 独立运行时，在支持完整保存与恢复配色的交互终端中临时使用黑底白字及统一强调色；正常结束、失败或可捕获中断后恢复进入前的配色，不修改终端全局偏好或 Shell 启动配置。不支持完整保护、无交互终端、`NO_COLOR`、既有纯文本模式和 Sourcetree 场景不切换配色，并沿用纯文本输出约定。强制终止（如 `kill -9`）无法由脚本自身保证恢复，请使用运行时显示的独立恢复入口。

<a id="🔚" href="#前言" style="font-size:17px; color:green; font-weight:bold;">我是有底线的➤点我回到首页</a>
