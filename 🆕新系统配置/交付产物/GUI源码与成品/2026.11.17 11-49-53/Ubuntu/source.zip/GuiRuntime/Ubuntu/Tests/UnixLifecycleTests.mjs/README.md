# UnixLifecycleTests.mjs

![Jobs出品，必属精品](https://picsum.photos/1500/400)

[toc]

---

## 🔥 <span id="前言">前言</span>

从自身目录定位六平台源脚本，在中文/空格临时目录建立假系统、包数据库和包管理器。仅替换临时副本的系统标记路径和状态位置，所有包命令均拦截，不调用真实 apt/dnf/apk/pkg，不安装/卸载本机软件。

## 一、<span id="run">运行</span> <a href="#前言" style="font-size:17px; color:green;"><b>🔼</b></a> <a href="#🔚" style="font-size:17px; color:green;"><b>🔽</b></a>

```sh
node './UnixLifecycleTests.mjs'
```

依赖开发机已有 [**Node.js**](https://nodejs.org/) 与 /bin/sh。输出逐平台结果、断言数及临时现场，保留现场供复核。覆盖预览不落盘、显式选择、错系统、取消、安装重复/失败、原有/版本变化/共享包保护、pending重试、锁、node/npm顺带收据及逆序卸载。终端为纯文本；隔离包行为不替代原生包事务、最低OS或真实终端验收。

<a id="🔚" href="#前言" style="font-size:17px; color:green; font-weight:bold;">我是有底线的➤点我回到首页</a>
