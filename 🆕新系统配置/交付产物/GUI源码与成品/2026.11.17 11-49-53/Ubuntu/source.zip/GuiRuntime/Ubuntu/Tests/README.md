# Unix 六平台隔离回归

![Jobs出品，必属精品](https://picsum.photos/1500/400)

[toc]

---

## 🔥 <span id="前言">前言</span>

[测试入口](./UnixLifecycleTests.mjs/UnixLifecycleTests.mjs)；[运行说明](./UnixLifecycleTests.mjs/README.md)。依赖开发机已有 [**Node.js**](https://nodejs.org/) 与 /bin/sh，非生产运行依赖。

<a id="🔚" href="#前言" style="font-size:17px; color:green; font-weight:bold;">我是有底线的➤点我回到首页</a>
